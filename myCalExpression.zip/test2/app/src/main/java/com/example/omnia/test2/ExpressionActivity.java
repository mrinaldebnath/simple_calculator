package com.example.omnia.test2;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import static java.lang.Math.ceil;
import static java.lang.Math.floor;

public class ExpressionActivity extends AppCompatActivity {

    //---------------------------------start of frontend variables declaration---------------------------------------------

    EditText edittextup;
    TextView infotextView;

    Button buttonseven;
    Button buttoneight ;
    Button buttonnine;
    Button buttonfour ;
    Button buttonfive ;
    Button buttonsix;
    Button buttonone ;
    Button buttontwo;
    Button buttonthree;
    Button buttondot ;
    Button buttonzero ;
    Button buttonequal ;
    Button buttonmultiply ;
    Button buttondivide ;
    Button buttonsubtract;
    Button buttonadd ;
    Button buttoncross ;
    Button buttonclear ;
    Button buttonans;
    Button buttonexpression;

    //-------------------end of frontend variables declaration-----------------------------

    //-----------------------start of backend variable declaration------------------------------

    private static final char ADDITION = '+';
    private static final char SUBTRACTION = '-';
    private static final char MULTIPLICATION = '*';
    private static final char DIVISION = '/';

    public char CURRENT_ACTION='n';

    private double valueOne =0.0;
    private double valueTwo=0.0;
    private double result=0.0;

    private int negativeUp=0;
    private int negative=0;

    //----------------------------end of backend variable declaration------------------------------

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_test);

        //----------------------binding front end variables to front end components----------------------

        edittextup = (EditText) findViewById(R.id.editTextUp);
        infotextView = (TextView) findViewById(R.id.infoTextView);
        
        edittextup.setShowSoftInputOnFocus(false);
        
        edittextup.setText("  ");

        buttonseven = (Button) findViewById(R.id.buttonSeven);
        buttoneight = (Button) findViewById(R.id.buttonEight);
        buttonnine = (Button) findViewById(R.id.buttonNine);
        buttonfour = (Button) findViewById(R.id.buttonFour);
        buttonfive = (Button) findViewById(R.id.buttonFive);
        buttonsix = (Button) findViewById(R.id.buttonSix);
        buttonone = (Button) findViewById(R.id.buttonOne);
        buttontwo = (Button) findViewById(R.id.buttonTwo);
        buttonthree = (Button) findViewById(R.id.buttonThree);
        buttondot = (Button) findViewById(R.id.buttonDot);
        buttonzero = (Button) findViewById(R.id.buttonZero);
        buttonequal = (Button) findViewById(R.id.buttonEqual);
        buttonmultiply = (Button) findViewById(R.id.buttonMultiply);
        buttondivide = (Button) findViewById(R.id.buttonDivide);
        buttonsubtract = (Button) findViewById(R.id.buttonSubtract);
        buttonadd = (Button) findViewById(R.id.buttonAdd);
        buttoncross = (Button) findViewById(R.id.buttonCross);
        buttonclear = (Button) findViewById(R.id.buttonClear);
        buttonans = (Button) findViewById(R.id.buttonAns);
        buttonexpression=(Button) findViewById(R.id.buttonExpression);

        //----------------------end of binding front end variables to front end components----------------------

        buttonexpression.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.activity_main_test);
            }
        });

        buttonans.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" "+result);

                }
            }
        });

        buttondot.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" .");

                }
            }
        });

        buttonzero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 0");

                }
            }
        });

        buttonone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 1");

                }
            }
        });

        buttontwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 2");

                }
            }
        });

        buttonthree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 3");

                }
            }
        });

        buttonfour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 4");

                }
            }
        });

        buttonfive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 5");

                }
            }
        });

        buttonsix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 6");

                }
            }
        });

        buttonseven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 7");

                }
            }
        });

        buttoneight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 8");

                }
            }
        });

        buttonnine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" 9");

                }
            }
        });

        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" +");

                }
            }
        });

        buttonsubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" -");

                }
            }
        });

        buttonmultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" *");

                }
            }
        });

        buttondivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    edittextup.setText(edittextup.getText().toString()+" /");

                }
            }
        });

        buttonequal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String primarytTextUp=edittextup.getText().toString();
                String primarytText=edittextup.getText().toString();

                if(CURRENT_ACTION!='n' && primarytTextUp.length()>2 && primarytText.length()>2)computeCalculation();




                String operation="";
                infotextView.setText("0.0");

                if(CURRENT_ACTION==ADDITION)
                {
                    operation=operation+"+";
                }

                if(CURRENT_ACTION==SUBTRACTION)
                {
                    operation=operation+"-";
                }

                if(CURRENT_ACTION==MULTIPLICATION)
                {
                    operation=operation+"*";
                }

                if(CURRENT_ACTION==DIVISION)
                {
                    operation=operation+"/";
                }

                if (CURRENT_ACTION=='n'|| primarytTextUp.length()<3 || primarytText.length()<3);
                else if(!operation.equals("/")  || valueTwo!=0.0)
                {
                    infotextView.setText(primarytTextUp.substring(2) + operation +primarytText.substring(2)+"\n"+"="+result );
                }
                else
                {
                    infotextView.setText("Math Error");
                }
                valueOne=0.0;
                valueTwo=0.0;
                result=0.0;
                edittextup.setText("  ");

                edittextup.clearFocus();

            }
        });

        buttonclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                edittextup.setText("  ");
                infotextView.setText("0.0");

            }
        });
        buttoncross.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edittextup.hasFocus())
                {
                    String primarytTextUp=edittextup.getText().toString();

                    if(primarytTextUp.length()>2)
                    {
                        edittextup.setText(primarytTextUp.substring(0,primarytTextUp.length()-1));
                    }

                }
                infotextView.setText("0.0");
            }
        });
    }

    private void computeCalculation() {

        valueOne=  Double.parseDouble(edittextup.getText().toString().substring(2));
        valueTwo = Double.parseDouble(edittextup.getText().toString().substring(2));

        if(CURRENT_ACTION == ADDITION)
            result = this.valueOne + valueTwo;
        else if(CURRENT_ACTION == SUBTRACTION)
            result = this.valueOne - valueTwo;
        else if(CURRENT_ACTION == MULTIPLICATION)
            result = this.valueOne * valueTwo;
        else if(CURRENT_ACTION == DIVISION)
        {
            if(valueTwo!=0.0)result = this.valueOne / valueTwo;
        }

    }

}

