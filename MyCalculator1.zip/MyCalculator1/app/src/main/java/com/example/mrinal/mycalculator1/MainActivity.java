package com.example.mrinal.mycalculator1;

import android.databinding.DataBindingUtil;
import android.icu.text.DecimalFormat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.mrinal.mycalculator1.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding binding;

    private static final char ADDITION = '+';
    private static final char SUBTRACTION = '-';
    private static final char MULTIPLICATION = '*';
    private static final char DIVISION = '/';

    public char CURRENT_ACTION='n';

    private double valueOne =0.0;
    private double valueTwo=0.0;
    private double result=0.0;
    private int AdecimalPoint=0;
    private int BdecimalPoint=0;
    

    

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        double decimalFormat ;

        binding = DataBindingUtil.setContentView(this, R.layout.activity_main);

        binding.editText.setSelectAllOnFocus(true);
        binding.editTextUp.setSelectAllOnFocus(true);
        


        binding.buttonDot.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                binding.infoTextView.setText("0.0");

                String op=" ";

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                    if(BdecimalPoint<1)binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + ".");
                    binding.editTextUp.clearFocus();
                    BdecimalPoint++;

                }
                else if(binding.editTextUp.hasFocus())
                {
                    if(AdecimalPoint<1)binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + ".");
                    binding.editText.clearFocus();
                    AdecimalPoint++;
                }
            }
        });

        binding.buttonZero.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                binding.infoTextView.setText("0.0");

                String op=" ";

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";


                if(binding.editText.hasFocus())
                {

                        binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "0");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {

                      binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "0");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonOne.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                binding.infoTextView.setText("0.0");

                String op=" ";

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                        binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "1");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "1");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                     binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "2");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "2");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonThree.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                      binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "3");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {

                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "3");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonFour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                        binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "4");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "4");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonFive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {

                        binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "5");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2)+ "5");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonSix.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                     binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "6");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2)+ "6");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonSeven.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                        binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "7");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "7");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonEight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                        binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "8");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "8");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonNine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String op=" ";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION!='n')op=op+CURRENT_ACTION;
                else op=op+" ";

                if(binding.editText.hasFocus())
                {
                    binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2) + "9");
                    binding.editTextUp.clearFocus();
                }
                else if(binding.editTextUp.hasFocus())
                {
                        binding.editTextUp.setText("  "+binding.editTextUp.getText().toString().substring(2) + "9");
                    binding.editText.clearFocus();
                }
            }
        });

        binding.buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CURRENT_ACTION = ADDITION;
                String op=" ";

                op=op+CURRENT_ACTION;
                binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2));

                binding.infoTextView.setText("0.0");
            }
        });

        binding.buttonSubtract.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CURRENT_ACTION = SUBTRACTION;
                String op=" ";

                op=op+CURRENT_ACTION;
                binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2));
                binding.infoTextView.setText("0.0");
            }
        });

        binding.buttonMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CURRENT_ACTION = MULTIPLICATION;
                String op=" ";

                op=op+CURRENT_ACTION;
                binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2));
                binding.infoTextView.setText("0.0");
            }
        });

        binding.buttonDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CURRENT_ACTION = DIVISION;
                String op=" ";

                op=op+CURRENT_ACTION;
                binding.editText.setText(op+" "+binding.editText.getText().toString().substring(2));
                binding.infoTextView.setText("0.0");
            }
        });

        binding.buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(CURRENT_ACTION!='n' && binding.editText.getText().toString().length()>2 && binding.editTextUp.getText().toString().length()>2)computeCalculation();

                binding.editText.clearFocus();
                binding.editTextUp.clearFocus();

                String operation="";
                binding.infoTextView.setText("0.0");

                if(CURRENT_ACTION==ADDITION)
                {
                    operation=operation+"+";
                }

                if(CURRENT_ACTION==SUBTRACTION)
                {
                    operation=operation+"-";
                }

                if(CURRENT_ACTION==MULTIPLICATION)
                {
                    operation=operation+"*";
                }

                if(CURRENT_ACTION==DIVISION)
                {
                    operation=operation+"/";
                }

                if (CURRENT_ACTION=='n'|| binding.editText.getText().toString().length()<3 || binding.editTextUp.getText().toString().length()<3);
                else if(operation!="/"  || valueTwo!=0.0)binding.infoTextView.setText(binding.editTextUp.getText().toString().substring(2) + operation +binding.editText.getText().toString().substring(2)+"\n"+"="+result );
                else binding.infoTextView.setText("Math Error");
                valueOne=0.0;
                valueTwo=0.0;
                result=0.0;
                binding.editTextUp.setText("  ");
                binding.editText.setText("  ");
                AdecimalPoint=0;
                BdecimalPoint=0;
                CURRENT_ACTION='n';

            }
        });

        binding.buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    CURRENT_ACTION='n';
                    valueOne = 0.0;
                    valueTwo =  0.0;
                    binding.editText.setText("  ");
                    binding.editTextUp.setText("  ");
                    binding.infoTextView.setText("0.0");

            }
        });
                binding.buttonCross.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        if(binding.editText.hasFocus())
                        {

                            if(binding.editText.getText().toString().length()>2)
                            {
                                if(binding.editText.getText().toString().charAt(binding.editText.getText().toString().length()-1)=='.')BdecimalPoint=0;
                                binding.editText.setText(binding.editText.getText().toString().substring(0,binding.editText.getText().toString().length()-1));
                            }
                            binding.editTextUp.clearFocus();
                        }
                        else if(binding.editTextUp.hasFocus())
                        {
                            if(binding.editTextUp.getText().toString().length()>2)
                            {
                                if(binding.editTextUp.getText().toString().charAt(binding.editTextUp.getText().toString().length()-1)=='.')AdecimalPoint=0;
                                binding.editTextUp.setText(binding.editTextUp.getText().toString().substring(0,binding.editTextUp.getText().toString().length()-1));
                            }
                            binding.editText.clearFocus();
                        }

                        binding.infoTextView.setText("0.0");

                    }
                });
    }

    private void computeCalculation() {

            valueOne=  Double.parseDouble(binding.editTextUp.getText().toString().substring(2));
            valueTwo = Double.parseDouble(binding.editText.getText().toString().substring(2));

            if(CURRENT_ACTION == ADDITION)
                result = this.valueOne + valueTwo;
            else if(CURRENT_ACTION == SUBTRACTION)
                result = this.valueOne - valueTwo;
            else if(CURRENT_ACTION == MULTIPLICATION)
                result = this.valueOne * valueTwo;
            else if(CURRENT_ACTION == DIVISION)
            {
                if(valueTwo!=0.0)result = this.valueOne / valueTwo;
            }

    }
}

